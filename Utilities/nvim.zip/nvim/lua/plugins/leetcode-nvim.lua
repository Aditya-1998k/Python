
return {
  {
    "kawre/leetcode.nvim",
    opts = {
      lang = "python3",
    },
  },
}
